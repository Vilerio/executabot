﻿const Discord = require('discord.js');
const client = new Discord.Client();
const token = require("./token.json");
const bdd = require("./bdd.json");
const fs = require("fs");
const bot = new Discord.Client();
const fetch = require('node-fetch') ;




bot.login(token.token);
bot.on("ready", async () => {
    console.log("[INFO] - Connecté en tant que : " + bot.user.tag)
    let phrase = [
        "//help",
        "Bot Developped by Olivier#2731",
    
    ];
    setInterval(function () {
        let random = phrase[Math.floor(Math.random() * phrase.length)];
        bot.user.setActivity(random, { type: "PLAYING" });
    }, 3000);
});

bot.on("guildMemberAdd", member => {
    
    if(bdd["message-bienvenue"]){
        bot.channels.cache.get('701770132812464169').send(bdd["message-bienvenue"]);
    }
    else{
        bot.channels.cache.get('701770132812464169').send("Bienvenue sur le serveur");
    }
    member.roles.add('701156465515167755');
    console.log("message de bienvenue")

})

bot.on("message", async message => {

   

client.on('message', msg => {
    if (msg.content === '//test') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Test")
            .setDescription("je fonctionne !")
            .setColor(0x0011ff);
        msg.channel.send(embed);
        console.log("test") 
    } else if (msg.content === '//test2') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Test2")
            .setDescription("je fonctionne toujours !")
            .setColor(0x0011ff);
        msg.channel.send(embed)
        console.log("test2")
    } else if (msg.content === '//Je veux jouer') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Tu veux jouer ?")
            .setDescription("A un Survie Faction ? Joue sur PVP Games !")
            .setColor(0x0011ff);
        msg.channel.send(embed);
    } else if (msg.content === '//help') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Information du bot")
            .setDescription("Information du bot - Commandes à exécuter")
            .setColor(0x0011ff)
            .addFields(
                { name: "Description", value: "Bonjour, je suis un super bot, qui fait aussi de la modération ! Voici les différentes commandes que tu peux exécuter (bot en cours de mise a jour !)", inline: false },
                { name: "Test", value: "//test", inline: true },
                { name: "Test2", value: "//test2", inline: true },
                { name: "Site web officiel", value: "//site", inline: true },
                { name: "Vote pour le serveur ! ", value: "//vote", inline: true },
                { name: "Infos dev du bot", value: "//dev", inline: true },
                { name: "Recherche de dev java", value: "//Recherche ou //Recherche everyone", inline: true },
                { name: "Je veux jouer", value: "//Je veux jouer", inline: true },
                { name: "Infos sur le bot et le serveur", value: "//infos", inline: true },
                { name: "Infos sur Minecraft", value: "//minecraft", inline: true },
                { name: "Infos sur PVP Games", value: "//PVP Games", inline: true },
                { name: "Infos détaillés", value: "//you", inline: true },
                { name: "Inviter quelqu'un sur le discord", value: "//invite-discord", inline: true },
                { name: "Version du bot", value: "//V-bot", inline: true },
                { name: "Infos sur le dev du bot", value: "//bot-dev", inline: true },
                { name: "Aller sur Wikipédia", value: "Wikipédia", inline: true },
                { name: "Infos sur Paladium", value: "//Paladium", inline: true },
                { name: "Supprimer des messages", value: "//clear nombre de messages", inline: true },
                { name: "Warn un utilisateur", value: "//warn @user", inline: true },
                { name: "Contacter modo", value: "//modo", inline: true },
                { name: "Upgrade du bot", value: "//up", inline: true },
            );
        msg.channel.send(embed);
            } else if (msg.content === '//minecraft') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Minecraft")
            .setDescription("Minecraft est un jeu vidéo de type  bac à sable  construction complètement libre développé par le Suédois Markus Persson, alias Notch, puis par la société Mojang Studios")
            .setColor(0x0011ff);
        msg.channel.send(embed);
    } else if (msg.content === '//PVP Games') {
        msg.channel.send('PVP Games est un serveur de pvp faction moddé https://discord.gg/K5VXfab');
        console.log(`Un joueur à executer la commande //PVP Games`);
    } else if (msg.content === 'Bonjour') {
        msg.channel.send('Bonjour, enchanté de vous voir !');
        console.log(`Un joueur à executer la commande Bonjour`);
    } else if (msg.content === 'Je te veux sur mon serveur') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Invite-moi sur ton serveur grace à ce lien !")
            .setDescription("https://discord.com/api/oauth2/authorize?client_id=716392851260571688&permissions=8&scope=bot")
            .setColor(0x0011ff);
        msg.channel.send(embed);
    } else if (msg.content === '//invite-bot') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Invite-moi sur ton serveur grace à ce lien !")
            .setDescription("https://discord.com/api/oauth2/authorize?client_id=716392851260571688&permissions=8&scope=bot")
            .setColor(0x0011ff);
        msg.channel.send(embed);
    } else if (msg.content === 'Météo svp') {
        msg.channel.send('Non mais, je ne suis pas présentateur météo, quel culot ! je vais le dire au staff !');
        console.log(`Un joueur veux la météo`);
    } else if (msg.content === '//you') {
        msg.channel.send('Je suis le bot officiel de PVP Games, en version publique, concu entièrement par @Olivier#2731');
    } else if (msg.content === 'PVP Games') {
        msg.channel.send('Ravi d\'entendre ce nom ! ');
    } else if (msg.content === 'Bienvenue') {
        msg.channel.send('Bienvenue sur ce serveur !');
    } else if (msg.content === '//invite-discord') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setTitle("Invite des gens sur le serveur discord PVP Games !  ")
            .setDescription("Invite des gens sur le serveur discord PVP Games grace à ce lien ! https://discord.gg/gB2PHJe ou viens sur mon serveur avec ce lien : https://discord.gg/x6ZhYxq")
            .setColor(0x0011ff);
        msg.channel.send(embed);
    } else if (msg.content === '//Joyeux anniversaire') {
        msg.channel.send('Joyeux anniversaire !!!!!!!!!!');
        console.log(`Happy birthday`);
    } else if (msg.content === 'Hello') {
        msg.channel.send('Hello = Bonjour en anglais');
    } else if (msg.content === 'PVP') {
        msg.channel.send('PvP (player vs player) is a multiplayer-only game mechanic, being an abbreviation for Player vs.');
    } else if (msg.content === 'Wikipédia') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Wikipédia")
            .setDescription("https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal")
            .setColor(0x0011ff);
        msg.channel.send(embed);
    } else if (msg.content === '//bot-dev') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Dev du bot")
            .setDescription("Ce bot est oppérationel ! il en est à la version 3.0 !")
            .setColor(0x0011ff);
        msg.channel.send(embed);
    } else if (msg.content === 'Ok') {
        msg.channel.send('Je confirme !');
    } else if (msg.content === 'Ban') {
        msg.reply('Qui tu veux bannir ? pour quelles raisons ?');
    } else if (msg.content === 'Salut') {
        msg.channel.send('Bienvenue ! Salut !');
    } else if (msg.content === '//V-bot') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Dev du bot")
            .setDescription("Cette version du bot de PVP Games, un serveur de pvp faction, est la version 3.0")
            .setColor(0x0011ff);
        msg.channel.send(embed);
    } else if (msg.content === 'Cool !') {
        msg.channel.send('Je confirme !');
    } else if (msg.content === 'Bye') {
        msg.channel.send('Bye !');
    } else if (msg.content === '//Paladium') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Paladium")
            .setDescription("Créé en 2015, Paladium est le plus gros serveur PvP-Faction francophone. Gratuit et moddé, il propose un système de faction, de PvP, de PvE, et de farming exclusif")
            .setColor(0x0011ff);
        msg.channel.send(embed);
    
    } 
  

});


client.on('message', msg => {
    if (msg.content === '//vote') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Viens voter pour pvp games ici ! ")
            .setDescription("https://discord-top.fr/serveur/860320be12a1c050cd7731794e231bd3 ou https://disboard.org/fr/server/703877902885847041")
            .setColor(0x0011ff);
        msg.channel.send(embed);
        console.log("vote") 

    } 
  

});


client.on('message', msg => {
    if (msg.content === '//site') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Site officiel de PVP Games : ")
            .setDescription("https://minecraft-pvpgames.wixsite.com/pvp-games")
            .setColor(0x0011ff);
        msg.channel.send(embed);
        console.log("site") 

    } 
  

});


client.on('message', msg => {
    if (msg.content === '//dev') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Developpeur de ce bot : ")
            .setDescription("Olivier#2731")
            .setColor(0x0011ff);
        msg.channel.send(embed);
        console.log("Dev") 

    } 
  

});


client.on('message', msg => {
    if (msg.content === '//xxx') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("PVP Games")
            .setColor('#0099ff')
            .setTitle("xxx")
            .setDescription("xxx ")
            .setColor(0x0011ff);
        msg.channel.send(embed);
        console.log("xxx") 

    } 
  

});

        
        



client.on('message', msg => {
    if (msg.content === '//up') {
        let embed = new Discord.MessageEmbed()
            .setAuthor("Executa")
            .setColor('#0099ff')
            .setTitle("Uprgrade le bot")
            .setDescription("Pour upgrade le bot, rejoins ce serveur : ")
            .setColor(0x0011ff);
        msg.channel.send(embed);
        console.log("up") 

    } 
  

});



client.login ('Nzc5Mzc2NTczMDg1MjUzNjU0.X7fo_w.OeCfnLb0KMnPzSiMBIC5PJLws2w')} )